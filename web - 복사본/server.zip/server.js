// ...existing code...
// 한국 IP 여부 확인 API
// (app이 선언된 후 아래에 위치해야 함)
// ...existing code...
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs'); // fs require를 path와 함께 위쪽에 위치
const { calculateNB } = require('./calculate');
const storage = require('./storage');
const config = require('./config.json');

const app = express();
const PORT = process.env.PORT || 3000;
const OLLAMA_BASE_URL = process.env.OLLAMA_BASE_URL || 'http://localhost:11434';
const TREND_DATA_PATH = path.join(__dirname, '..', 'data', 'naver_creator_trends', 'latest_trend_data.json');
const DEFAULT_MODEL = process.env.OLLAMA_MODEL || 'llama3';

// MMDB 파일 경로 선언
const MMDB_PATH = path.join(__dirname, 'GeoLite2-Country.mmdb');

// GeoIP MMDB 라이브러리 추가
const maxmind = require('maxmind');
let geoipLookup = null;
if (fs.existsSync(MMDB_PATH)) {
    maxmind.open(MMDB_PATH)
        .then(lookup => {
            geoipLookup = lookup;
            console.log('[GeoIP] MMDB 로드 성공');
        })
        .catch(err => {
            console.error('[GeoIP] MMDB 로드 실패:', err);
        });
} else {
    console.warn(`[GeoIP] MMDB 파일이 없습니다. 다운로드 필요: ${MMDB_PATH}`);
    // MMDB 다운로드 안내
    console.warn('GeoLite2-Country.mmdb 파일을 https://dev.maxmind.com/geoip/geolite2-free-geolocation-data?lang=ko 에서 다운로드 후 server.js와 같은 폴더에 넣으세요.');
}


// 스토리지 초기화
storage.initStorage();

// 도메인 검증 미들웨어 (CORS 전에 실행)
app.use((req, res, next) => {
    const host = req.get('host') || req.hostname || 'unknown';
    const allowedDomains = config.allowedDomains || [];
    
    // 포트 제거해서 도메인만 비교
    const hostWithoutPort = host.split(':')[0].toLowerCase();
    
    console.log(`[DEBUG] Host: ${host} | hostname: ${req.hostname} | hostWithoutPort: ${hostWithoutPort} | allowedDomains: ${allowedDomains.join(', ')}`);
    
    // localhost는 항상 허용 (개발 환경)
    if (hostWithoutPort === 'localhost' || hostWithoutPort === '127.0.0.1' || hostWithoutPort === '::1') {
        console.log(`[허용됨] localhost 개발 환경`);
        return next();
    }
    
    // 허용된 도메인 확인 (www 버전도 포함)
    const isAllowed = allowedDomains.some(domain => {
        const domainLower = domain.toLowerCase();
        return hostWithoutPort === domainLower || 
               hostWithoutPort === 'www.' + domainLower;
    });
    
    if (!isAllowed) {
        console.warn(`[차단됨] 허용되지 않은 도메인 접속 시도: ${hostWithoutPort} from IP: ${req.ip}`);
        // 연결을 즉시 끊음 (페이지 표시 안 함)
        return res.destroy();
    }
    
    console.log(`[허용됨] 도메인: ${hostWithoutPort}`);
    next();
});

// CORS 설정
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    if (req.method === 'OPTIONS') {
        return res.sendStatus(200);
    }
    next();
});

// 미들웨어
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public', '한국인터넷.한국')));

// 방문 기록 미들웨어
app.use((req, res, next) => {
    const ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';
    const rawKeyword = req.query.keyword || req.query.nb || req.body.input || null;
    const keyword = normalizeKeyword(rawKeyword);
    
    storage.recordVisit(ip, req.path, userAgent, keyword);
    next();
});

const calculationConfig = {
    bitDefaultValue: 999,
    decimalPlaces: 10,
    calculationCountForText: 1
};

function normalizeKeyword(rawText) {
    if (!rawText || typeof rawText !== 'string') {
        return '';
    }
    const firstLine = rawText.split('\n')[0].trim();
    if (!firstLine || firstLine === '-') {
        return '';
    }
    return firstLine.slice(0, 60);
}

function loadTrendKeywords(limit) {
    if (!fs.existsSync(TREND_DATA_PATH)) {
        return [];
    }
    const raw = fs.readFileSync(TREND_DATA_PATH, 'utf-8');
    const data = JSON.parse(raw);
    const trends = Array.isArray(data.trend_data) ? data.trend_data : [];
    const keywords = trends
        .map(item => normalizeKeyword(item.raw_text || item.title || ''))
        .filter(Boolean);
    return keywords.slice(0, limit);
}

async function fetchPageText(url) {
    if (typeof fetch !== 'function') {
        return { url, title: '', description: '', text: '' };
    }
    const response = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' } });
    const html = await response.text();
    const titleMatch = html.match(/<title>([^<]*)<\/title>/i);
    const descMatch = html.match(/<meta\s+name=["']description["']\s+content=["']([^"']*)["']\s*\/?/i);
    const bodyText = html
        .replace(/<script[\s\S]*?<\/script>/gi, ' ')
        .replace(/<style[\s\S]*?<\/style>/gi, ' ')
        .replace(/<[^>]+>/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
        .slice(0, 1200);
    return {
        url,
        title: titleMatch ? titleMatch[1].trim() : '',
        description: descMatch ? descMatch[1].trim() : '',
        text: bodyText
    };
}

async function callOllama(prompt, model) {
    if (typeof fetch !== 'function') {
        throw new Error('fetch API를 사용할 수 없습니다.');
    }
    const response = await fetch(`${OLLAMA_BASE_URL}/api/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model, prompt, stream: false })
    });
    const data = await response.json();
    return (data && data.response) ? data.response.trim() : '';
}

function safeJsonParse(text) {
    try {
        return JSON.parse(text);
    } catch (error) {
        return null;
    }
}

// 홈페이지
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', '한국인터넷.한국', 'index.html'));
});

// API: 계산 요청
app.post('/api/calculate', async (req, res) => {
    try {
        const { input, bit = calculationConfig.bitDefaultValue, category = 'general' } = req.body;
        
        if (!input) {
            return res.status(400).json({ error: '입력값이 없습니다.' });
        }

        // 숫자 배열인지 확인
        let values = [];
        if (typeof input === 'string') {
            values = input.replace(/,/g, ' ').split(/\s+/).filter(x => x.trim()).map(parseFloat);
        } else if (Array.isArray(input)) {
            values = input;
        }

        // 숫자 검증
        if (Array.isArray(values) && values.length >= 2 && values.every(v => !isNaN(v))) {
            // 숫자 계산
            const maxResult = calculateNB(values, bit, false);
            const minResult = calculateNB(values, bit, true);
            
            const result = {
                type: 'number',
                input: values,
                bit: bit,
                category: category,
                nb_max: parseFloat(maxResult.toFixed(calculationConfig.decimalPlaces)),
                nb_min: parseFloat(minResult.toFixed(calculationConfig.decimalPlaces)),
                difference: parseFloat((maxResult - minResult).toFixed(calculationConfig.decimalPlaces))
            };

            // 데이터베이스에 저장
            const saveResult = await storage.saveCalculation(result);
            
            if (saveResult.success && saveResult.calculation) {
                // 저장된 완전한 객체(view_count 포함)를 반환
                return res.json({
                    ...saveResult.calculation,
                    saved: true,
                    calculation_id: saveResult.id
                });
            } else {
                result.saved = saveResult.success;
                result.calculation_id = saveResult.id;
                return res.json(result);
            }
        } else {
            // 문자 계산
            const unicodeArray = Array.from(input).map(char => char.charCodeAt(0));
            
            if (unicodeArray.length === 0) {
                return res.status(400).json({ error: '유효한 입력이 없습니다.' });
            }

            // 3회 계산
            const results = [];
            for (let i = 0; i < calculationConfig.calculationCountForText; i++) {
                const maxResult = calculateNB(unicodeArray, bit, false);
                const minResult = calculateNB(unicodeArray, bit, true);
                
                results.push({
                    calculation: i + 1,
                    nb_max: parseFloat(maxResult.toFixed(calculationConfig.decimalPlaces)),
                    nb_min: parseFloat(minResult.toFixed(calculationConfig.decimalPlaces)),
                    difference: parseFloat((maxResult - minResult).toFixed(calculationConfig.decimalPlaces))
                });
            }

            const result = {
                type: 'text',
                input: input,
                unicode: unicodeArray,
                bit: bit,
                category: category,
                results: results
            };

            // 데이터베이스에 저장
            const saveResult = await storage.saveCalculation(result);
            
            if (saveResult.success && saveResult.calculation) {
                // 저장된 완전한 객체(view_count 포함)를 반환
                return res.json({
                    ...saveResult.calculation,
                    saved: true,
                    calculation_id: saveResult.id
                });
            } else {
                result.saved = saveResult.success;
                result.calculation_id = saveResult.id;
                return res.json(result);
            }
        }
    } catch (error) {
        console.error('계산 오류:', error);
        res.status(500).json({ error: error.message });
    }
});

// API: 검색 (Unicode 배열 또는 텍스트)
// API: 검색 (POST + GET 지원, ID 검색 추가)
app.post('/api/search', async (req, res) => {
    try {
        const { text, unicode, id, limit } = req.body;
        
        let results = [];
        const searchLimit = parseInt(limit) || 10;
        
        if (id) {
            // ID로 검색 (조회수 증가)
            const calculation = await storage.loadCalculation(id, true);
            if (calculation) {
                results = [calculation];
            }
        } else if (unicode && Array.isArray(unicode)) {
            // Unicode 배열로 검색
            results = await storage.searchByUnicode(unicode);
        } else if (text) {
            // 텍스트로 검색
            results = await storage.searchByText(text, searchLimit);
        } else {
            return res.status(400).json({ error: '검색어를 입력해주세요.' });
        }
        
        return res.json({
            success: true,
            count: results.length,
            results: results
        });
    } catch (error) {
        console.error('검색 오류:', error);
        res.status(500).json({ error: error.message });
    }
});

// API: 검색 (GET 요청 지원 - 조회수 증가용)
app.get('/api/search', async (req, res) => {
    try {
        const { text, id, limit } = req.query;
        
        let results = [];
        const searchLimit = parseInt(limit) || 10;
        
        if (id) {
            // ID로 검색 (조회수 증가)
            const calculation = await storage.loadCalculation(id, true);
            if (calculation) {
                results = [calculation];
            }
        } else if (text) {
            // 텍스트로 검색
            results = await storage.searchByText(text, searchLimit);
        } else {
            return res.status(400).json({ error: '검색어를 입력해주세요.' });
        }
        
        return res.json({
            success: true,
            count: results.length,
            results: results
        });
    } catch (error) {
        console.error('검색 오류:', error);
        res.status(500).json({ error: error.message });
    }
});

// API: 최근 계산 결과
app.get('/api/recent', async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 10;
        const results = await storage.getRecentCalculations(limit);
        
        return res.json({
            success: true,
            count: results.length,
            results: results
        });
    } catch (error) {
        console.error('최근 결과 조회 오류:', error);
        res.status(500).json({ error: error.message });
    }
});

// API: 통계
app.get('/api/stats', async (req, res) => {
    try {
        const stats = await storage.getStatistics();
        return res.json(stats);
    } catch (error) {
        console.error('통계 조회 오류:', error);
        res.status(500).json({ error: error.message });
    }
});

// API: RSS 피드 (dlvr.it용)
app.get('/feed.xml', async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 30;
        const results = await storage.getRecentCalculations(limit);
        
        // RSS 2.0 형식의 XML 생성
        const siteUrl = 'https://xn--9l4b4xi9r.com'; // 참소식.com의 실제 도메인으로 변경 필요
        const feedUrl = `${siteUrl}/feed.xml`;
        
        const buildDate = new Date().toUTCString();
        
        // 각 항목의 아이템 생성
        const items = results.map(item => {
            const pubDate = new Date(item.timestamp).toUTCString();
            const category = item.category || '일반';
            const title = item.input instanceof Array ? `[${item.input.join(', ')}]` : item.input;
            const cleanTitle = typeof title === 'string' ? title.replace(/\*/g, '') : title;
            const nbMax = (item.results && item.results[0] && item.results[0].nb_max) || 0;
            const nbMin = (item.results && item.results[0] && item.results[0].nb_min) || 0;
            
            // index.html 검색 링크 형식
            const itemLink = `${siteUrl}/index.html?search=${encodeURIComponent(cleanTitle)}&selected_max=${nbMax}&selected_min=${nbMin}`.replace(/&/g, '&amp;');
            
            const description = `
                <p><strong>카테고리:</strong> ${category}</p>
                <p><strong>MAX:</strong> ${nbMax} | <strong>MIN:</strong> ${nbMin}</p>
                <p><strong>유형:</strong> ${item.type === 'text' ? '텍스트' : '숫자'}</p>
                <p><strong>조회수:</strong> ${item.view_count || 0}</p>
            `.trim();
            
            return `
    <item>
        <title><![CDATA[${title}]]></title>
        <description><![CDATA[${description}]]></description>
        <link>${itemLink}</link>
        <category><![CDATA[${category}]]></category>
        <pubDate>${pubDate}</pubDate>
        <guid>${siteUrl}#${item.id || item.timestamp}</guid>
    </item>
            `.trim();
        }).join('\n');
        
        const rss = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0">
    <channel>
        <title>참소식.com - N/B 데이터베이스</title>
        <link>${siteUrl}</link>
        <description>참소식 - 최신 N/B 계산 결과</description>
        <language>ko-kr</language>
        <lastBuildDate>${buildDate}</lastBuildDate>
        <image>
            <title>참소식.com</title>
            <url>${siteUrl}/logo.png</url>
            <link>${siteUrl}</link>
        </image>
${items}
    </channel>
</rss>`;
        
        res.type('application/xml; charset=utf-8');
        res.send(rss);
    } catch (error) {
        console.error('RSS 피드 생성 오류:', error);
        res.status(500).type('application/xml').send(`<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0">
    <channel>
        <title>참소식.com - 오류</title>
        <link>https://xn--9l4b4xi9r.com</link>
        <description>오류가 발생했습니다.</description>
    </channel>
</rss>`);
    }
});

// API: 조회수가 가장 많은 결과
app.get('/api/most-viewed', async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 10;
        const results = await storage.getMostViewedCalculations(limit);
        
        return res.json({
            success: true,
            count: results.length,
            results: results
        });
    } catch (error) {
        console.error('조회수 많은 순 조회 오류:', error);
        res.status(500).json({ error: error.message });
    }
});

// XML 이스케이프 함수
function escapeXml(str) {
    if (!str) return '';
    return str.replace(/[<>&'"]/g, (char) => {
        const entities = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            "'": '&apos;',
            '"': '&quot;'
        };
        return entities[char] || char;
    });
}

// API: RSS 피드 - 인기글 (dlvr.it용)
app.get('/feed-popular.xml', async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 30;
        const results = await storage.getMostViewedCalculations(limit);
        
        // RSS 2.0 형식의 XML 생성
        const siteUrl = 'https://xn--9l4b4xi9r.com'; // 참소식.com의 실제 도메인으로 변경 필요
        const feedUrl = `${siteUrl}/feed-popular.xml`;
        
        const buildDate = new Date().toUTCString();
        
        // 각 항목의 아이템 생성
        const items = results.map(item => {
            const pubDate = new Date(item.timestamp).toUTCString();
            const category = item.category || '일반';
            const title = item.input instanceof Array ? `[${item.input.join(', ')}]` : item.input;
            const cleanTitle = typeof title === 'string' ? title.replace(/\*/g, '') : title;
            const nbMax = (item.results && item.results[0] && item.results[0].nb_max) || 0;
            const nbMin = (item.results && item.results[0] && item.results[0].nb_min) || 0;
            
            // index.html 검색 링크 형식
            const itemLink = `${siteUrl}/index.html?search=${encodeURIComponent(cleanTitle)}&selected_max=${nbMax}&selected_min=${nbMin}`.replace(/&/g, '&amp;');
            
            const description = `
                <p><strong>카테고리:</strong> ${category}</p>
                <p><strong>MAX:</strong> ${nbMax} | <strong>MIN:</strong> ${nbMin}</p>
                <p><strong>유형:</strong> ${item.type === 'text' ? '텍스트' : '숫자'}</p>
                <p><strong>조회수:</strong> ${item.view_count || 0}</p>
            `.trim();
            
            return `
    <item>
        <title><![CDATA[${title}]]></title>
        <description><![CDATA[${description}]]></description>
        <link>${itemLink}</link>
        <category><![CDATA[${category}]]></category>
        <pubDate>${pubDate}</pubDate>
        <guid>${siteUrl}#${item.id || item.timestamp}</guid>
    </item>
            `.trim();
        }).join('\n');
        
        const rss = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0">
    <channel>
        <title>참소식.com - 인기글</title>
        <link>${siteUrl}</link>
        <description>참소식 - 조회수 많은 N/B 계산 결과</description>
        <language>ko-kr</language>
        <lastBuildDate>${buildDate}</lastBuildDate>
        <image>
            <title>참소식.com</title>
            <url>${siteUrl}/logo.png</url>
            <link>${siteUrl}</link>
        </image>
${items}
    </channel>
</rss>`;
        
        res.type('application/xml; charset=utf-8');
        res.send(rss);
    } catch (error) {
        console.error('인기글 RSS 피드 생성 오류:', error);
        res.status(500).type('application/xml').send(`<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0">
    <channel>
        <title>참소식.com - 오류</title>
        <link>https://xn--9l4b4xi9r.com</link>
        <description>오류가 발생했습니다.</description>
    </channel>
</rss>`);
    }
});

// API: Sitemap (SEO)
app.get('/sitemap.xml', async (req, res) => {
    try {
        const siteUrl = 'https://xn--9l4b4xi9r.com';
        const lastMod = new Date().toISOString().split('T')[0];
        
        let urls = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <url>
        <loc>${siteUrl}/</loc>
        <lastmod>${lastMod}</lastmod>
        <changefreq>daily</changefreq>
        <priority>1.0</priority>
    </url>
    <url>
        <loc>${siteUrl}/feed.xml</loc>
        <lastmod>${lastMod}</lastmod>
        <changefreq>hourly</changefreq>
        <priority>0.8</priority>
    </url>
    <url>
        <loc>${siteUrl}/feed-popular.xml</loc>
        <lastmod>${lastMod}</lastmod>
        <changefreq>hourly</changefreq>
        <priority>0.8</priority>
    </url>
</urlset>`;
        
        res.type('application/xml; charset=utf-8');
        res.send(urls);
    } catch (error) {
        console.error('Sitemap 생성 오류:', error);
        res.status(500).send('오류가 발생했습니다.');
    }
});

// API: robots.txt
app.get('/api/track-keyword', (req, res) => {
    const keyword = normalizeKeyword(req.query.keyword || '');
    if (!keyword) {
        return res.json({ success: false, message: 'keyword required' });
    }
    return res.json({ success: true });
});

// API: 트렌드 기반 AI 콘텐츠 생성 (Ollama)
app.post('/api/trend-ai', async (req, res) => {
    try {
        const limit = Math.min(parseInt(req.body.limit, 10) || 5, 20);
        const model = req.body.model || DEFAULT_MODEL;
        const keywords = loadTrendKeywords(limit);

        if (keywords.length === 0) {
            return res.status(404).json({
                success: false,
                error: '트렌드 키워드를 찾을 수 없습니다.'
            });
        }

        const results = [];
        for (const keyword of keywords) {
            const naverUrl = `https://search.naver.com/search.naver?query=${encodeURIComponent(keyword)}`;
            const youtubeUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(keyword)}`;

            const questionPrompt = `키워드: ${keyword}\n요구사항: 한국어 질문형 한 문장만 출력.`;
            let question = '';
            try {
                question = await callOllama(questionPrompt, model);
            } catch (error) {
                question = `${keyword}에 대해 알고 싶어요.`;
            }

            const [naverInfo, youtubeInfo] = await Promise.all([
                fetchPageText(naverUrl),
                fetchPageText(youtubeUrl)
            ]);

            const contentPrompt = [
                '다음 정보를 참고해 한국어로 JSON만 출력해줘.',
                '필드: title, summary, body',
                `키워드: ${keyword}`,
                `질문: ${question}`,
                `네이버 텍스트: ${naverInfo.title} ${naverInfo.description} ${naverInfo.text}`,
                `유튜브 텍스트: ${youtubeInfo.title} ${youtubeInfo.description} ${youtubeInfo.text}`,
                '제목은 40자 이내, summary는 2문장, body는 3~5문장으로 작성.'
            ].join('\n');

            let generated = { title: '', summary: '', body: '' };
            try {
                const response = await callOllama(contentPrompt, model);
                const parsed = safeJsonParse(response);
                if (parsed && parsed.title && parsed.summary && parsed.body) {
                    generated = parsed;
                } else {
                    generated = {
                        title: `${keyword} 관련 요약`,
                        summary: response.slice(0, 220),
                        body: response
                    };
                }
            } catch (error) {
                generated = {
                    title: `${keyword} 관련 요약`,
                    summary: '요약 생성에 실패했습니다.',
                    body: '본문 생성에 실패했습니다.'
                };
            }

            results.push({
                keyword,
                question,
                search: {
                    naver: naverUrl,
                    youtube: youtubeUrl
                },
                source_text: {
                    naver: naverInfo,
                    youtube: youtubeInfo
                },
                generated
            });
        }

        return res.json({
            success: true,
            model,
            count: results.length,
            results
        });
    } catch (error) {
        console.error('트렌드 AI 오류:', error);
        res.status(500).json({ error: error.message });
    }
});

// API: 단일 조회 (계산 ID로 조회)
app.get('/api/calculation/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await storage.loadCalculation(id);
        
        if (result) {
            return res.json({
                success: true,
                result: result
            });
        } else {
            return res.status(404).json({
                success: false,
                error: '계산 결과를 찾을 수 없습니다.'
            });
        }
    } catch (error) {
        console.error('단일 조회 오류:', error);
        res.status(500).json({ error: error.message });
    }
});

// API: 리스트 조회 (페이징)
app.get('/api/calculations', async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 20;
        const results = await storage.getRecentCalculations(limit);
        
        return res.json({
            success: true,
            page: page,
            limit: limit,
            count: results.length,
            results: results
        });
    } catch (error) {
        console.error('리스트 조회 오류:', error);
        res.status(500).json({ error: error.message });
    }
});

// 헬스 체크
app.get('/api/health', (req, res) => {
    res.json({ status: 'OK', message: 'N/B 계산 서버 정상 작동 중' });
});

// ===== 방문 통계 API =====

// 시간대별 방문 통계
app.get('/api/visits/hourly', async (req, res) => {
    try {
        const hourly = await storage.getVisitsByHour();
        return res.json({
            success: true,
            data: hourly
        });
    } catch (error) {
        console.error('시간대별 방문 조회 오류:', error);
        res.status(500).json({ error: error.message });
    }
});

// 지역별 방문 통계
app.get('/api/visits/region', async (req, res) => {
    try {
        const regions = await storage.getVisitsByRegion();
        return res.json({
            success: true,
            data: regions
        });
    } catch (error) {
        console.error('지역별 방문 조회 오류:', error);
        res.status(500).json({ error: error.message });
    }
});

// ===== 키워드 통계 API =====

// 전체 인기 키워드
app.get('/api/keywords/top', async (req, res) => {
    try {
        const limit = Math.min(parseInt(req.query.limit) || 20, 100);
        const keywords = await storage.getTopKeywords(limit);
        return res.json({
            success: true,
            count: keywords.length,
            data: keywords
        });
    } catch (error) {
        console.error('인기 키워드 조회 오류:', error);
        res.status(500).json({ error: error.message });
    }
});

// 지역별 인기 키워드
app.get('/api/keywords/by-region', async (req, res) => {
    try {
        const limit = Math.min(parseInt(req.query.limit) || 10, 50);
        const keywords = await storage.getKeywordsByRegion(limit);
        return res.json({
            success: true,
            data: keywords
        });
    } catch (error) {
        console.error('지역별 키워드 조회 오류:', error);
        res.status(500).json({ error: error.message });
    }
});

// 서버 시작
const server = app.listen(PORT, () => {
    console.log(`
╔════════════════════════════════════════════════════════════════════╗
║           N/B MAX, N/B MIN 계산 웹서버                           ║
║           서버 시작됨                                            ║
╚════════════════════════════════════════════════════════════════════╝

🌐 서버가 실행 중입니다:
   URL: http://localhost:${PORT}
   
📊 API 엔드포인트:
   POST /api/calculate         - N/B 계산 및 저장
   POST /api/search            - 검색 (텍스트/Unicode)
   GET  /api/recent            - 최근 계산 결과 (날짜순)
   GET  /api/most-viewed       - 조회수 많은 순 (NEW)
    POST /api/trend-ai          - 트렌드 AI 콘텐츠 생성 (Ollama)
   GET  /api/stats             - 통계 정보
   GET  /api/calculation/:id   - 단일 조회 (ID)
   GET  /api/calculations      - 리스트 조회 (페이징)
   GET  /api/health            - 헬스 체크

💡 종료: Ctrl+C
    `);

    // 1시간(3600000ms) 마다 자동 재부팅
    const ONE_HOUR = 3600000; // 1시간 = 3600000ms
    setInterval(() => {
        console.log('\n⚠️  [자동 재부팅] 1시간 경과 - 서버 재부팅 시작...');
        console.log(`⏰ 재부팅 시간: ${new Date().toLocaleString('ko-KR')}`);
        
        // 서버 종료 (PM2/배치파일이 자동으로 재시작)
        server.close(() => {
            console.log('✅ 서버 종료 완료. 재시작 대기 중...');
            process.exit(0);
        });
        
        // 강제 종료 (30초 후에도 안 닫혀있으면)
        setTimeout(() => {
            console.error('❌ 강제 종료 (30초 타임아웃)');
            process.exit(1);
        }, 30000);
    }, ONE_HOUR);
});
