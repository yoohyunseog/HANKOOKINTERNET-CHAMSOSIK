<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>미분 이해하기</title>
  <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
</head>
<body>
  <h2>미분 시각화: f(x) = x²</h2>
  <div id="plot" style="width:100%;height:500px;"></div>

  <script>
    // 함수 정의: f(x) = x^2
    function f(x) {
      return x * x;
    }

    // 미분 정의: f'(x) = 2x
    function df(x) {
      return 2 * x;
    }

    // x 값 범위
    let xValues = [];
    let yValues = [];
    for (let i = -10; i <= 10; i += 0.1) {
      xValues.push(i);
      yValues.push(f(i));
    }

    // 특정 점에서 접선 그리기
    let x0 = 2; // 접선을 그릴 기준점
    let slope = df(x0);
    let tangentY = xValues.map(x => f(x0) + slope * (x - x0));

    // 그래프 데이터
    let traceFunction = {
      x: xValues,
      y: yValues,
      mode: 'lines',
      name: 'f(x) = x²',
      line: {color: 'blue'}
    };

    let traceTangent = {
      x: xValues,
      y: tangentY,
      mode: 'lines',
      name: `접선 (x=${x0}, 기울기=${slope})`,
      line: {color: 'red', dash: 'dash'}
    };

    let tracePoint = {
      x: [x0],
      y: [f(x0)],
      mode: 'markers',
      name: '접점',
      marker: {color: 'black', size: 10}
    };

    let data = [traceFunction, traceTangent, tracePoint];

    let layout = {
      title: '미분의 의미: 함수와 접선',
      xaxis: {title: 'x'},
      yaxis: {title: 'y'}
    };

    Plotly.newPlot('plot', data, layout);