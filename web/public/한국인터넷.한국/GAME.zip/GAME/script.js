const state = {
  minute: 12 * 60,
  score: 0,
  selectedSector: 0,
  gameOver: false,
  paused: false,
  resources: {
    hull: 100,
    fuel: 78,
    ammo: 70,
    deck: 84,
    morale: 82,
    intel: 46
  },
  squadrons: [
    { id: "VFA-1", type: "F/A-18E", role: "다목적", status: "ready", hp: 100, eta: 0 },
    { id: "VFA-2", type: "F/A-18E", role: "타격", status: "ready", hp: 100, eta: 0 },
    { id: "VAW-3", type: "E-2D", role: "조기경보", status: "ready", hp: 100, eta: 0 },
    { id: "HSM-4", type: "MH-60R", role: "대잠", status: "ready", hp: 100, eta: 0 },
    { id: "VFA-5", type: "F-35C", role: "스텔스", status: "maintenance", hp: 86, eta: 2 },
    { id: "VRC-6", type: "CMV-22", role: "보급", status: "ready", hp: 100, eta: 0 }
  ],
  sectors: [
    { name: "북서 해역", kind: "missile", threat: 62, patrol: 0, revealed: true },
    { name: "북동 공역", kind: "air", threat: 55, patrol: 0, revealed: true },
    { name: "동해 항로", kind: "sub", threat: 42, patrol: 0, revealed: true },
    { name: "남부 접근로", kind: "surface", threat: 28, patrol: 0, revealed: true },
    { name: "서해 보급로", kind: "raid", threat: 35, patrol: 0, revealed: false },
    { name: "원해 초계선", kind: "unknown", threat: 24, patrol: 0, revealed: false },
    { name: "항모 근접권", kind: "air", threat: 18, patrol: 1, revealed: true },
    { name: "연합 작전구", kind: "surface", threat: 22, patrol: 0, revealed: true },
    { name: "대잠 탐색구", kind: "sub", threat: 38, patrol: 0, revealed: false },
    { name: "전자전 구역", kind: "raid", threat: 46, patrol: 0, revealed: true },
    { name: "상륙 예비권", kind: "unknown", threat: 20, patrol: 0, revealed: false },
    { name: "후방 정비권", kind: "surface", threat: 12, patrol: 0, revealed: true }
  ],
  intelCards: [],
  logs: [],
  result: ""
};

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const actions = [
  { id: "launchCap", label: "CAP 출격", desc: "공중 위협과 미사일 위협을 낮춥니다." },
  { id: "launchStrike", label: "타격 출격", desc: "고위협 구역을 크게 낮추지만 탄약 소모가 큽니다." },
  { id: "launchAsw", label: "대잠 초계", desc: "잠수함 위협에 강합니다." },
  { id: "launchRecon", label: "정찰 출격", desc: "숨은 위협을 공개하고 정보 우위를 높입니다." },
  { id: "scan", label: "장거리 탐지", desc: "정보를 소모해 여러 구역을 밝힙니다." },
  { id: "jam", label: "전자전 교란", desc: "전체 위협 상승을 잠시 억제합니다." }
];

function clamp(value, min = 0, max = 100) {
  return Math.max(min, Math.min(max, value));
}

function percent(value) {
  return `${Math.round(value)}%`;
}

function formatTime(minute) {
  const h = Math.floor(minute / 60);
  const m = minute % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}

function addLog(message, type = "info") {
  state.logs.unshift({ time: formatTime(state.minute), message, type });
  state.logs = state.logs.slice(0, 12);
}

function readySquadron(preferredRoles = []) {
  const ready = state.squadrons.filter((s) => s.status === "ready" && s.hp > 35);
  return ready.find((s) => preferredRoles.includes(s.role)) || ready[0];
}

function selectedSector() {
  return state.sectors[state.selectedSector];
}

function spend(cost) {
  for (const [key, value] of Object.entries(cost)) {
    if (state.resources[key] < value) return false;
  }
  for (const [key, value] of Object.entries(cost)) {
    state.resources[key] = clamp(state.resources[key] - value);
  }
  return true;
}

function completeMission(squadron) {
  const sector = state.sectors[squadron.target];
  if (!sector) return;

  if (squadron.mission === "CAP") {
    const effect = sector.kind === "air" || sector.kind === "missile" ? 22 : 12;
    sector.threat = clamp(sector.threat - effect);
    sector.patrol = clamp(sector.patrol + 1, 0, 3);
    state.score += 45 + effect;
    addLog(`${squadron.id} CAP 완료: ${sector.name} 위협 감소`);
  }

  if (squadron.mission === "STRIKE") {
    const effect = sector.threat > 65 ? 34 : 24;
    sector.threat = clamp(sector.threat - effect);
    state.score += 80 + effect;
    addLog(`${squadron.id} 타격 성공: ${sector.name} 제압`);
  }

  if (squadron.mission === "ASW") {
    const effect = sector.kind === "sub" ? 32 : 14;
    sector.threat = clamp(sector.threat - effect);
    sector.revealed = true;
    state.score += 55 + effect;
    addLog(`${squadron.id} 대잠 초계 완료`);
  }

  if (squadron.mission === "RECON") {
    sector.revealed = true;
    sector.threat = clamp(sector.threat - 8);
    state.resources.intel = clamp(state.resources.intel + 18);
    state.score += 40;
    addIntelCard(`${sector.name} 정찰`, `${sector.kind.toUpperCase()} 활동 패턴 확인. 대응 정확도 상승.`);
    addLog(`${squadron.id} 정찰 자료 송신`);
  }

  const risk = Math.max(2, sector.threat / 7 - sector.patrol * 2);
  if (Math.random() * 100 < risk) {
    squadron.hp = clamp(squadron.hp - (12 + Math.random() * 18));
    addLog(`${squadron.id} 손상 발생, 정비 필요`, "warn");
  }

  squadron.status = squadron.hp < 55 ? "maintenance" : "ready";
  squadron.eta = squadron.status === "maintenance" ? 3 : 0;
  squadron.mission = "";
  squadron.target = null;
}

function addIntelCard(title, body) {
  state.intelCards.unshift({ title, body });
  state.intelCards = state.intelCards.slice(0, 8);
}

function launchMission(mission) {
  if (state.gameOver) return;
  const sector = selectedSector();
  const missionConfig = {
    CAP: { cost: { fuel: 8, deck: 5 }, roles: ["다목적", "스텔스", "조기경보"], eta: 2 },
    STRIKE: { cost: { fuel: 12, ammo: 16, deck: 8 }, roles: ["타격", "스텔스", "다목적"], eta: 3 },
    ASW: { cost: { fuel: 9, deck: 5 }, roles: ["대잠", "다목적"], eta: 3 },
    RECON: { cost: { fuel: 7, deck: 4 }, roles: ["조기경보", "스텔스", "다목적"], eta: 2 }
  }[mission];

  const squadron = readySquadron(missionConfig.roles);
  if (!squadron) {
    addLog("출격 가능한 편대가 없습니다.", "warn");
    return;
  }

  if (!spend(missionConfig.cost)) {
    addLog("자원이 부족해 임무를 시작할 수 없습니다.", "warn");
    return;
  }

  squadron.status = "airborne";
  squadron.mission = mission;
  squadron.target = state.selectedSector;
  squadron.eta = missionConfig.eta;
  addLog(`${squadron.id} ${mission} 임무 출격: ${sector.name}`);
  render();
}

function command(action) {
  if (state.gameOver) {
    if (action === "restart") restart();
    return;
  }

  if (action === "launchCap") launchMission("CAP");
  if (action === "launchStrike") launchMission("STRIKE");
  if (action === "launchAsw") launchMission("ASW");
  if (action === "launchRecon") launchMission("RECON");

  if (action === "scan") {
    if (!spend({ intel: 12 })) return addLog("정보 우위가 부족합니다.", "warn");
    state.sectors.forEach((sector, index) => {
      if (index % 2 === state.minute % 2) sector.revealed = true;
    });
    state.score += 25;
    addIntelCard("장거리 탐지", "미확인 접촉 다수 식별. 숨은 구역 일부 공개.");
    addLog("장거리 탐지 실행");
  }

  if (action === "jam") {
    if (!spend({ intel: 18 })) return addLog("전자전 실행에 필요한 정보가 부족합니다.", "warn");
    state.sectors.forEach((sector) => sector.threat = clamp(sector.threat - 6));
    state.score += 30;
    addLog("전자전 교란으로 적 지휘망 약화");
  }

  if (action === "resupply") {
    state.resources.fuel = clamp(state.resources.fuel + 18);
    state.resources.ammo = clamp(state.resources.ammo + 14);
    state.resources.deck = clamp(state.resources.deck - 6);
    state.score = Math.max(0, state.score - 20);
    addLog("보급 요청 완료: 연료와 탄약 증가");
  }

  if (action === "restCrew") {
    state.resources.morale = clamp(state.resources.morale + 12);
    state.resources.deck = clamp(state.resources.deck - 4);
    addLog("승조원 교대 편성");
  }

  if (action === "cycleDeck") {
    state.resources.deck = clamp(state.resources.deck + 8);
    state.resources.morale = clamp(state.resources.morale - 2);
    addLog("갑판 순환 최적화");
  }

  if (action === "repairDeck") {
    if (!spend({ deck: 0 })) return;
    state.resources.deck = clamp(state.resources.deck + 16);
    state.resources.morale = clamp(state.resources.morale - 5);
    state.squadrons.filter((s) => s.status === "maintenance").forEach((s) => {
      s.hp = clamp(s.hp + 12);
      s.eta = Math.max(1, s.eta - 1);
    });
    addLog("갑판 복구와 긴급 정비 실시");
  }

  if (action === "recoverAll") {
    state.squadrons.filter((s) => s.status === "airborne").forEach((s) => {
      s.eta = 1;
    });
    state.resources.deck = clamp(state.resources.deck - 8);
    addLog("전 기체 회수 절차 개시");
  }

  render();
}

function enemyTurn() {
  const intelMitigation = state.resources.intel / 80;
  let totalThreat = 0;

  state.sectors.forEach((sector) => {
    const patrolReduction = sector.patrol * 0.6;
    const growth = Math.random() * 4 + 1.6 - intelMitigation - patrolReduction;
    sector.threat = clamp(sector.threat + growth, 0, 100);
    sector.patrol = Math.max(0, sector.patrol - 0.18);
    totalThreat += sector.threat;
  });

  const exposedThreat = state.sectors
    .filter((sector) => sector.threat > 70)
    .reduce((sum, sector) => sum + sector.threat - 70, 0);

  if (exposedThreat > 0) {
    const damage = exposedThreat / 18;
    state.resources.hull = clamp(state.resources.hull - damage);
    state.resources.morale = clamp(state.resources.morale - damage * 0.7);
    addLog(`고위협 구역 방치: 함체 피해 ${damage.toFixed(1)}%`, "warn");
  }

  if (Math.random() < 0.22) {
    const hidden = state.sectors.filter((sector) => !sector.revealed);
    const target = hidden[Math.floor(Math.random() * hidden.length)];
    if (target) {
      target.threat = clamp(target.threat + 12);
      addLog("미확인 접촉이 빠르게 접근 중", "warn");
    }
  }

  state.resources.fuel = clamp(state.resources.fuel - 0.6);
  state.resources.morale = clamp(state.resources.morale - 0.25);
  state.score += Math.round(Math.max(0, 80 - totalThreat / state.sectors.length) / 8);
}

function progressSquadrons() {
  state.squadrons.forEach((squadron) => {
    if (squadron.status === "airborne" || squadron.status === "maintenance") {
      squadron.eta -= 1;
    }
    if (squadron.status === "airborne" && squadron.eta <= 0) completeMission(squadron);
    if (squadron.status === "maintenance" && squadron.eta <= 0) {
      squadron.hp = clamp(squadron.hp + 18);
      squadron.status = squadron.hp >= 70 ? "ready" : "maintenance";
      squadron.eta = squadron.status === "maintenance" ? 2 : 0;
      if (squadron.status === "ready") addLog(`${squadron.id} 정비 완료`);
    }
  });
}

function checkEnd() {
  if (state.score >= 500) {
    state.gameOver = true;
    state.result = "승리";
    addLog("승리: 전역 통제 점수 500점 달성", "good");
  }
  if (state.minute >= 18 * 60) {
    state.gameOver = true;
    state.result = state.score >= 420 ? "작전 성공" : "작전 실패";
    addLog(state.score >= 420 ? "작전 성공: 제한 시간 생존" : "작전 실패: 통제 점수 부족", state.score >= 420 ? "good" : "warn");
  }
  if (state.resources.hull <= 0 || state.resources.morale <= 0) {
    state.gameOver = true;
    state.result = "작전 실패";
    addLog("작전 실패: 항모전단 전투 지속 불가", "warn");
  }
}

function tick() {
  if (state.paused || state.gameOver) return;
  state.minute += 10;
  progressSquadrons();
  enemyTurn();
  checkEnd();
  render();
}

function restart() {
  window.location.reload();
}

function resourceRows() {
  const labels = {
    hull: "함체",
    fuel: "항공유",
    ammo: "탄약",
    deck: "갑판",
    morale: "사기",
    intel: "정보"
  };
  return Object.entries(state.resources).map(([key, value]) => {
    const level = value < 30 ? "bad" : value < 55 ? "warn" : "";
    return `
      <article class="resource">
        <header><span>${labels[key]}</span><b>${percent(value)}</b></header>
        <div class="bar ${level}"><span style="width:${value}%"></span></div>
      </article>
    `;
  }).join("");
}

function renderSectors() {
  $("#sectorGrid").innerHTML = state.sectors.map((sector, index) => {
    const threatText = sector.revealed ? percent(sector.threat) : "???";
    const danger = sector.threat > 70 ? "danger" : "";
    const selected = index === state.selectedSector ? "selected" : "";
    return `
      <article class="sector ${danger} ${selected}" data-sector="${index}">
        <div>
          <h3>${sector.name}</h3>
          <p>${sector.revealed ? sector.kind.toUpperCase() : "UNKNOWN"}</p>
        </div>
        <div class="threat">${threatText}</div>
        <div class="patrol">초계 ${sector.patrol.toFixed(1)}</div>
      </article>
    `;
  }).join("");
  $$(".sector").forEach((card) => {
    card.addEventListener("click", () => {
      state.selectedSector = Number(card.dataset.sector);
      render();
    });
  });
}

function renderActions() {
  $("#actionButtons").innerHTML = actions.map((action) => `
    <button data-action="${action.id}">
      ${action.label}<br><small>${action.desc}</small>
    </button>
  `).join("");
}

function renderSquadrons() {
  $("#squadronList").innerHTML = state.squadrons.map((s) => {
    const tagClass = s.status === "airborne" ? "air" : s.status === "maintenance" ? "maint" : s.hp < 55 ? "damaged" : "";
    const statusText = s.status === "ready" ? "대기" : s.status === "airborne" ? `${s.mission} T-${s.eta}` : `정비 T-${s.eta}`;
    return `
      <article class="squadron-card">
        <div>
          <h3>${s.id} · ${s.type}</h3>
          <p>${s.role} / 내구 ${percent(s.hp)}</p>
        </div>
        <span class="tag ${tagClass}">${statusText}</span>
      </article>
    `;
  }).join("");
}

function renderDeck() {
  const positions = [
    [23, 24], [31, 24], [39, 24], [24, 70], [34, 68], [48, 29]
  ];
  $("#deckAircraft").innerHTML = state.squadrons.map((s, index) => {
    const [left, top] = positions[index] || [20 + index * 8, 52];
    return `<div class="aircraft-token" style="left:${left}%;top:${top}%">${s.id}</div>`;
  }).join("");
}

function renderIntel() {
  if (state.intelCards.length === 0) {
    state.intelCards.push({ title: "초기 정보", body: "북서 해역과 북동 공역의 위협이 빠르게 상승 중입니다." });
  }
  $("#intelCards").innerHTML = state.intelCards.map((card) => `
    <article class="intel-card">
      <div>
        <h3>${card.title}</h3>
        <p>${card.body}</p>
      </div>
      <span class="tag">INTEL</span>
    </article>
  `).join("");
}

function renderLog() {
  $("#log").innerHTML = state.logs.map((entry) => `<p>${entry.time} ${entry.message}</p>`).join("");
}

function renderAdvice() {
  const sector = selectedSector();
  const high = sector.threat > 70;
  const hidden = !sector.revealed;
  let text = `${sector.name} 선택됨. `;
  if (hidden) text += "먼저 정찰 또는 장거리 탐지로 정보를 확보하세요.";
  else if (sector.kind === "sub") text += "대잠 초계가 가장 효율적입니다.";
  else if (sector.kind === "air" || sector.kind === "missile") text += "CAP 출격으로 피해를 줄이세요.";
  else if (high) text += "타격 출격으로 빠르게 제압하세요.";
  else text += "초계 유지 또는 정보 확보가 좋습니다.";
  $("#advice").textContent = text;
}

function renderHeader() {
  $("#clock").textContent = formatTime(state.minute);
  $("#score").textContent = state.score;
  $("#gameState").textContent = state.gameOver ? "종료" : "작전 중";
}

function renderResult() {
  const panel = $("#resultPanel");
  if (!state.gameOver) {
    panel.classList.add("hidden");
    return;
  }
  panel.classList.remove("hidden");
  $("#resultTitle").textContent = state.result || "작전 종료";
  $("#resultText").textContent = `최종 점수 ${state.score}점 / 함체 ${percent(state.resources.hull)} / 사기 ${percent(state.resources.morale)}`;
}

function render() {
  renderHeader();
  $("#resourceList").innerHTML = resourceRows();
  renderSectors();
  renderActions();
  renderSquadrons();
  renderDeck();
  renderIntel();
  renderLog();
  renderAdvice();
  renderResult();
}

$$(".tabs button").forEach((button) => {
  button.addEventListener("click", () => {
    $$(".tabs button").forEach((tab) => tab.classList.remove("active"));
    $$(".page").forEach((page) => page.classList.remove("active"));
    button.classList.add("active");
    $(`#${button.dataset.page}`).classList.add("active");
  });
});

document.body.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-action]");
  if (button) command(button.dataset.action);
});

addLog("작전 개시. 목표: 18:00 전까지 통제 점수 500점.");
addLog("위협 구역을 선택한 뒤 임무를 지시하세요.");
render();
setInterval(tick, 1800);
